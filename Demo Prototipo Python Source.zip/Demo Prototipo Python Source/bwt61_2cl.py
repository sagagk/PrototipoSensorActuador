# By Alberto Caro S
# Dr.(c) Cs. Ingenieria - PUC
# Ingeniero Civil Informatico
# Profesor Asistente - Univ. Catolica Temuco
# Dpto Ingenieria Civil Infomatica
#------------------------------------------------
# App Sensor Inercial - Kinecting
#-----------------------------------------------------------------------------
# Obs: Decodificacion de Trama de Datos del Sensor Inercial BlueTooth BWT61CL.
#      Iniciamos el Test con un solo sensor BWT61CL.
#      Despues haremos el Test con los 2 Sensores BWT61CL de manera simultanea. 
#-----------------------------------------------------------------------------
# TRAMA : |0x55|0x51|0x53|LSB|MSB|LSB|MSB|LSB|MSB|......
# 0x55 -> Init Trama de datos del BWT61CL
# 0x51 -> Datos Acele XYZ + 6 Bytes = [(LSB + MSB*256)/32768]*16 -> [G, m/s2]
# 0x53 -> Datos Giro  XYZ + 6 Bytes = [(LSB + MSB*256)/32768]*180-> [Grados/s]
# Sampling BWT61CL ->  115200 BPS
#-----------------------------------------------------------------------------
import serial as RS, struct as ST, time as Ti

nMAX_G = 16

sLine_1 = 'Ax: %02.2f Ay: %02.2f Az: %02.2f'
sLine_2 = 'Wx: %03.2f Wy: %03.1f Wz: %03.1f'
sLine_3 = 'Roll: %03.2f Pitch: %03.2f Yaw: %03.2f'

s = RS.Serial('COM9') ; s.baudrate = 9600 # Puerto enlace del BWT61CL
r = RS.Serial('COM2') ; r.baudrate = 9600 # Puerto RS-232 Virtual Python & Delphi

#------------------------------------------------------------------------------
# Check Suma -> Verifica que la trama de datos es correcta. Con el BWT61CL
#               no es necesario utilizarla pues la Trama rara vez genera ERROR.
#------------------------------------------------------------------------------
def CS(aPaq):
    nAux = sum(aPaq[:8]) % 0xff
    print('Trama->' + str(aPaq)) 
    print('Suma ->' + str(sum(aPaq[:8])))
    print('CS 1   ' + str(nAux))
    print('CS 2   ' + str(aPaq[8]))
    return (nAux == aPaq[8])

#------------------------------------------------------------------------------
# Get_ACE() -> Decodifica la trama de datos de ACEL XYZ del sensor BWT61CL.
#              Se utiliza Decodificacion Native Little Endian
#------------------------------------------------------------------------------
def Get_ACE():
    sT  = s.read(6) # LSB|MSB|LSB|MSB|LSB|MSB| -> Aceleracion
    aD  = ST.unpack('@BbBbBb',sT) # Formato Native Little Endian
    nV1 = aD[0] + aD[1]*256 ; nV2 = aD[2] + aD[3]*256 ; nV3 = aD[4] + aD[5]*256
    nX  = (nV1/32768.0) * 16; nY  = (nV2/32768.0) * 16 ; nZ  = (nV3/32768.0) * 16 
    sL  = '{A,' + str(nV1) + ',' + str(nV2) + ',' + str(nV3) + '}' # Datos Aceleracion
    r.write(sL) # Envio de Trama Aceleracion a Sistema de Delphi
    print(sLine_1 % (nX,nY,nZ))
    return

#------------------------------------------------------------------------------
# Get_ACE() -> Decodifica la trama de datos de GIRO XYZ del sensor BWT61CL.
#              Se utiliza Decodificacion Native Little Endian
#------------------------------------------------------------------------------
def Get_ANG():
    sT  = s.read(6) # LSB|MSB|LSB|MSB|LSB|MSB| -> Giroscopio
    aD  = ST.unpack('@BbBbBb',sT) # Formato Native Little Endian
    nV1 = aD[0] + aD[1]*256 ; nV2 = aD[2] + aD[3]*256 ; nV3 = aD[4] + aD[5]*256
    nX  = (nV1/32768.0)*180 ; nY  = (nV2/32768.0)*180 ; nZ  = (nV3/32768.0)*180
    sL  = '{G,' + str(nV1) + ',' + str(nV2) + ',' + str(nV3) + '}' # Datos Giroscopio
    r.write(sL)# Envio de Trama Giroscopo a Sistema de Delphi
    print(sLine_2 % (nX,nY,nZ))
    return 
    
#------------------------------------------------------------------------------
# Main Code Python - By Alberto Caro S. 
#------------------------------------------------------------------------------
while 1: 
 sT = s.read(2) # Leemos los 2 primeros Bytes del Sensor BWT61CL 
 aD = ST.unpack('B'*len(sT),sT) # Decodificamos con unpack(.)
 if (aD[0] == 0x55):# Es Init Trama del Sensor BWT61CL ?
    if (aD[1] == 0x51): # Es Data trama Aceleracion?
        Get_ACE() # Decodificamos y enviamos a App Delphi  
    if (aD[1] == 0x53): # Data trama Giroscopo
        Get_ANG() # Decodificamos y enviamos a App Delphi    

s.close() ; r.close() # Free Connection COMxs 

 
