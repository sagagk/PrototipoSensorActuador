# By Alberto Caro S
# Dr.(c) Cs. Ingenieria - PUC
# Ingeniero Civil Informatico
# Profesor Asistente - Univ. Catolica Temuco
# Dpto Ingenieria Civil Infomatica
#------------------------------------------------
# App Sensor Inercial - Kinecting
# Obs: Simulacion y codificacion de Trama de Datos del
# Sensor Inercial BlueTooth BWT61CL
# TRAMA : |0x55|0x51|0x53|LSB|MSB|LSB|MSB|LSB|MSB|......
# 0x55 -> Init Trama de datos del BWT61CL
# 0x51 -> Datos Acele XYZ + 6 Bytes = [(LSB + MSB*256)/32768]*16 -> [G, m/s2]
# 0x53 -> Datos Giro  XYZ + 6 Bytes = [(LSB + MSB*256)/32768]*180-> [Grados/s]
# Sampling BWT61CL ->  115200 BPS
#-----------------------------------------------------------------------------

import serial as RS, struct as ST, time as Ti, random as ra

nG = 16  # Maxima Fuerza G del Sensor
nR = 180 # Radianes para conversion a Grados

sLine_1 = 'Ax: %02.2f Ay: %02.2f Az: %02.2f'
sLine_2 = 'Wx: %03.2f Wy: %03.1f Wz: %03.1f'
sLine_3 = 'Roll: %03.2f Pitch: %03.2f Yaw: %03.2f'

r = RS.Serial('COM2') ; r.baudrate = 9600 # Coneccion Serial Real o Virtual

#-----------------------------------------------------------------------------
#Generando Trama datos Acel-XYZ Sensor Inercial Testeo Interfaz 1
#-----------------------------------------------------------------------------
def Get_ACE():
    nV1 = ra.randint(-3000,3000)
    nV2 = ra.randint(-3000,3000) 
    nV3 = ra.randint(-3000,3000)
    nX  = (nV1/32768.0)*nG; nY = (nV2/32768.0)*nG ; nZ  = (nV3/32768.0)*nG 
    # A = Aceleracion
    sL  = '{A,' + str(nV1) + ',' + str(nV2) + ',' + str(nV3) + '}' # Datos Aceleracion
    r.write(sL) # Envio de Trama Aceleracion por RS-232 9600-8N1 -> To App Delphi
    print(sLine_1 % (nX,nY,nZ))
    return
#-----------------------------------------------------------------------------
#Generando Trama datos Giro-XYZ Sensor Inercial Testeo Interfaz 1
#-----------------------------------------------------------------------------
def Get_ANG():
    nV1 = ra.randint(-10000,13000)
    nV2 = ra.randint(-10000,13000) 
    nV3 = ra.randint(-10000,13000)
    nX  = (nV1/32768.0)*nR ; nY  = (nV2/32768.0)*nR ; nZ  = (nV3/32768.0)*nR
    # G = Giro/Orientacion
    sL  = '{G,' + str(nV1) + ',' + str(nV2) + ',' + str(nV3) + '}' # Datos Giroscopio
    r.write(sL)# Envio de Trama Giro-XYZ por RS-232 9600-8N1 -> To App Delphi
    print(sLine_2 % (nX,nY,nZ))
    return 
#-----------------------------------------------------------------------------
# Main Code Python
#-----------------------------------------------------------------------------
while 1: 
 Get_ACE()   # Generamos Trama valida Acel XYZ segun Protocolo del BWT61CL
 Get_ANG()   # Generamos Trama valida Giro XYZ segun Protocolo del BWT61CL
 Ti.sleep(0.1)
 
r.close() # Cerramos RS-232

