# By Alberto Caro S
# Dr.(c) Cs. Ingenieria - PUC
# Ingeniero Civil Informatico
# Profesor Asistente - Univ. Catolica Temuco
# Dpto Ingenieria Civil Infomatica
#------------------------------------------------
# App Sensor Inercial - Kinecting
#-----------------------------------------------------------------------------
# Obs: Decodificacion de Trama de Datos del Sensor Inercial BlueTooth BWT61CL.
#      Iniciamos el Test con 2 Sensores BWT61CL BlueTooth
#      Sensor 1 -> Port COM 09 -> 9600 Bps - 8N1
#      Sensor 2 -> Port COM 10 -> 9600 Bps - 8N1
#-----------------------------------------------------------------------------
# TRAMA : |0x55|0x51|0x53|LSB|MSB|LSB|MSB|LSB|MSB|......
# 0x55 -> Init Trama de datos del BWT61CL
# 0x51 -> Datos Acele XYZ + 6 Bytes = [(LSB + MSB*256)/32768]*16 -> [G, m/s2]
# 0x53 -> Datos Giro  XYZ + 6 Bytes = [(LSB + MSB*256)/32768]*180-> [Grados/s]
# Max Sampling BWT61CL ->  115200 BPS
#-----------------------------------------------------------------------------
import serial as RS, struct as ST, time as Ti

nFG = 16.00 ; nAG = 180.00 

lS11_OK = True ; lS12_OK = True ; lS21_OK = True ; lS22_OK = True

sLine_1 = 'Ax: %02.2f Ay: %02.2f Az: %02.2f'
sLine_2 = 'Wx: %03.2f Wy: %03.1f Wz: %03.1f'
sLine_3 = 'Roll: %03.2f Pitch: %03.2f Yaw: %03.2f'

rv = RS.Serial('COM2') ; rv.baudrate = 9600 # Rs-232 Virtual Serial Emulator
s1 = RS.Serial('COM9') ; s1.baudrate = 9600 # RS-232 Sensor Inercial 1
s2 = RS.Serial('COM10') ; s2.baudrate = 9600 # RS-232 Sensor Inercial 2

#-----------------------------------------------------------------------------
# Decodificamos los datos de Aceleracion y Giroscopo del 1er Sensor BWT61CL.0x51
# Esta operacion se debe sincronizar en conjunto con la otra trama del Sensor 2.
# Se debe garantizar que los datos de AceleXYZ + GIRO XYZ esten decodificados
# completa y correctamente antes de enviarlos a la APP Delphi para su registro
# en la base de datos historica y su graficacion.
#-----------------------------------------------------------------------------
def Get_Data_S1():
    global lS11_OK; global lS12_OK  ;  lTrama_OK = False ; sTrama_OK = ''
    while (1):
     sSync = s1.read(2)
     aD    = ST.unpack('B'*len(sSync),sSync)
     if (aD[0] == 0x55):# Es Head Trama?
         if (aD[1] == 0x51): # Data trama aceleracion?
             if lS11_OK:
                sT  = s1.read(6) # Trama de la Aceleracion
                aD  = ST.unpack('@BbBbBb',sT) # Formato Native Little Endian
                nV1 = aD[0]+aD[1]*256; nV2 = aD[2]+aD[3]*256; nV3 = aD[4]+aD[5]*256
                sL1 = str(nV1) + ',' + str(nV2) + ',' + str(nV3) # Datos Aceleracion S1
                lS11_OK = False # Cambiamos estado pues ho hay que volver a leer
         if (aD[1] == 0x53): # Data trama Giroscopo?
             if lS12_OK:
                sT  = s1.read(6) # Giroscopio
                aD  = ST.unpack('@BbBbBb',sT) # Formato Native Little Endian
                nV1 = aD[0]+aD[1]*256; nV2 = aD[2]+aD[3]*256; nV3 = aD[4]+aD[5]*256
                sL2 = str(nV1) + ',' + str(nV2) + ',' + str(nV3) # Datos Giroscopio
                lS12_OK = False # Cambiamos estado pues ho hay que volver a leer

#[Aqui esta la MAGIA]---------------------------------------------------------
     lTrama_OK = (not lS11_OK) and (not lS12_OK) # Trama Inercial Completa?
#-----------------------------------------------------------------------------

     if (lTrama_OK):
         sTrama_OK = '{1,' + sL1 + ',' + sL2 + '}' # Trama Completa Sensor Inercial 1
         lS11_OK = True ; lS12_OK = True ; nC = 0 # Actualizamos Estados....
         break

    return (lTrama_OK,sTrama_OK)

#-----------------------------------------------------------------------------
# Decodificamos los datos de Aceleracion y Giroscopo del 2do Sensor BWT61CL.
# Esta operacion se debe sincronizar en conjunto con la otra trama del Sensor 2.
# Se debe garantizar que los datos de AceleXYZ + GIRO XYZ esten decodificados
# completa y correctamente antes de enviarlos a la APP Delphi para su registro
# en la base de datos historica y su graficacion.
#-----------------------------------------------------------------------------
def Get_Data_S2():
    global lS21_OK; global lS22_OK ; lTrama_OK = False ; sTrama_OK = ''
    while (1):
     sSync = s2.read(2)
     aD    = ST.unpack('B'*len(sSync),sSync)
     if (aD[0] == 0x55):# Es Head Trama?
         if (aD[1] == 0x51): # Data trama aceleracion?
             if lS21_OK:
                sT  = s2.read(6) # Trama de la Aceleracion
                aD  = ST.unpack('@BbBbBb',sT) # Formato Native Little Endian
                nV1 = aD[0]+aD[1]*256; nV2 = aD[2]+aD[3]*256; nV3 = aD[4]+aD[5]*256
                sL1 = str(nV1) + ',' + str(nV2) + ',' + str(nV3) # Datos Aceleracion S1
                lS21_OK = False # Cambiamos estado pues ho hay que volver a leer
         if (aD[1] == 0x53): # Data trama Giroscopo?
             if lS22_OK:
                sT  = s2.read(6) # Giroscopio
                aD  = ST.unpack('@BbBbBb',sT) # Formato Native Little Endian
                nV1 = aD[0]+aD[1]*256; nV2 = aD[2]+aD[3]*256; nV3 = aD[4]+aD[5]*256
                sL2 = str(nV1) + ',' + str(nV2) + ',' + str(nV3) # Datos Giroscopio
                lS22_OK = False # Cambiamos estado pues ho hay que volver a leer

#[Aqui esta la MAGIA]---------------------------------------------------------
     lTrama_OK = (not lS21_OK) and (not lS22_OK) # Trama Inercial Completa?
#-----------------------------------------------------------------------------

     if (lTrama_OK):
         sTrama_OK = '{2,' + sL1 + ',' + sL2 + '}' # Trama Completa Sensor Inercial 1
         lS21_OK = True ; lS22_OK = True
         break

    return (lTrama_OK,sTrama_OK)

#-----------------------------------------------------------------------------
# Main Code Python  By Alberto Caro
#-----------------------------------------------------------------------------

nFh = open('datos.csv','w') # Generamos datos Mode Texto CSV excel o Pandas

while 1: 
 sSen1 = Get_Data_S1()[1] # Obtenemos datos de ACEL-XYZ + GIRO-XYZ 1er Sensor 
 sSen2 = Get_Data_S2()[1] # Obtenemos datos de ACEL-XYZ + GIRO-XYZ 2do Sensor
 rv.write(sSen1) # Enviamos datos 1er Sensor To App Delphi por RS-232 COM2
 rv.write(sSen2) # Enviamos datos 2do Sensor To App Delphi por RS-232 COM2
 nFh.write(sSen1 + '\n') # Escribimos los datos a datos.csv
 nFh.write(sSen2 + '\n')
 print(sSen1) # Datos a terminal standar
 print(sSen2)
 
rv.close() ; s1.close() ;s2.close() ; nFh.close() # Kill Any Port.-

Ahora voy a mover ambos sensores.....Ahora estan en reposo.